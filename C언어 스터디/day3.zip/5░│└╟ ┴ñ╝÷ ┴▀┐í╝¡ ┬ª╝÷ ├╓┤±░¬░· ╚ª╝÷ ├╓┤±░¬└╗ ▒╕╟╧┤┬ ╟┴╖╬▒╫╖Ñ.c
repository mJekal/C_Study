#include <stdio.h>
#define NUMBER 5

int main(void)
{
    int i, oddMax, evenMax;
    oddMax = 0;
    evenMax = 0;
    int array[NUMBER];
    for (i = 0; i < NUMBER; i++)
    {
        scanf("%d", &array[i]);
        if (array[i] % 2 == 0)
        {
            if (array[i] > evenMax)
            {
                evenMax = array[i];
            }
        }
        else
        {
            if (array[i] < oddMax)
            {
                oddMax = array[i];
            }
        }
    }
    printf("%d %d", oddMax, evenMax);
    return 0;
}