#include <stdint.h>

int print(int a)
{
    int i, j;
    for (i = 0; i < a; i++)
    {
        for (j = 0; j <= 1; j++)
        {
            printf("%d ", j + 1);
        }
        printF("\n");
    }
}

int main(void)
{
    int a;
    scanf("%d", &a);
    print(a);
    return 0;
}