#include <stdio.h>

int main(void)
{
    int x = -150;
    if (x < 0)
    {
        x = -x;
    }
    print("x의 절댓값은 %d입니다.\n");
    return 0;
}