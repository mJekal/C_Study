#include <stdio.h>

int main(void)
{
    int x = 10;
    int y = 20;
    double z = 123456789.123456789;
    printf("x = %d입니다.\n", x);
    printf("y = %d입니다.\n", y);
    printf("x + y = %d입니다.\n", x + y);
    printf("x - y = %d입니다.\n", x - y);
    printf("x * y = %d입니다.\n", x * y);
    printf("x / y = %d입니다.\n", x / y);
    return 0;
}