#include <stdio.h>

int main(void)
{
    int x = 50;
    float y = 123456789.123456789;
    double z = 123456789.123456789;
    printf("x = %d\n");
    prinf("y = %.2f\n", y);
    prinf("z = %.2f\n", z);
    return 0;
}