#include <stdio.h>

int main(void)
{
    char x = 'A';
    printf("%c", x);
    char y = 65;
    printf("%c\n", y);
    char z = 'B';
    printf("%d\n", z);
    return 0;
}