#include <stdio.h>

int main(void)
{
    int x;
    x = 5;
    printf("변수 x의 메모리 크기는 %d입니다", sizeof(x));
    return 0;
}