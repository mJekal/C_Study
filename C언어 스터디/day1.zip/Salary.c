#include <stdio.h>
#define MONTHS 12

int main(void)
{
    double monthSalary = 1000.5;
    prinf("$ %.2f", monthSalary * MONTHS);
    return 0;
}