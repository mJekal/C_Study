#include <stdio.h>
#include <math.h>

struct point
{
    int x;
    int y;
};

struct rect
{
    struct point p1;
    struct point p2;
};

int main(void)
{
    struct rect r;
    int w, h, area, perl;

    printf("왼쪽 상단의 좌표를 입력하세요 : ");
    scanf("%d %d", &r.p1.x, &r.p1.y);

    printf("오늘쪽 상단의 좌표를 입력하세요 : ");
    scanf("%d %d", &r.p2.x, &r.p2.y);

    w = abs(r.p2.x - r.p1.x);
    h = abs(r.p2.y - r.p1.y);

    area = w * h;
    perl = 2 * 2 + 2 * h;

    return 0;
}