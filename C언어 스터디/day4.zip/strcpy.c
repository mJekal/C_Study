#include <stdio.h>
#include <string.h>

int main(void) {
    char input[10] = "나동빈";
    char result[10] = "홍길동";
    strcpy(result, input);
    printf("문자열 복사 : %s\n", result);
    return 0;
}