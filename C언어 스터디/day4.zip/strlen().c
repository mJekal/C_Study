#include <stdio.h>
#include <string.h>

int main(void) 
{
    char input[5] = "Love";
    printf("문자열의 길이 : %d\n", strlen(input));
    return 0;
}